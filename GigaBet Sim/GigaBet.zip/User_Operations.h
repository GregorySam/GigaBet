#pragma once
#include "Punter.h"


bool Got_To_Next_Category_User(string);

bool Got_To_Next_Category_Director(string);


string Visit_Account(Punter&);


void Go_To_Home();


void Change_Price_Display();




void Show_Last_Bets();


void Go_Back();

void Give_Coupon_To_User();

string Place_New_Bet(Punter&);

void Users_Management();

void Show_25_last_actions();

void Rename_Node();

void New_Node();

void Remove_Node();

void Copy_Node();

void Change_Visibility_Of_Node();

void Void(User&);

void Settle(User&);